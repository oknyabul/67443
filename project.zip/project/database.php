<?php
	$user = 'u67443'; 
	$pass = '3234547'; 
	$db = new PDO('mysql:host=localhost;dbname=u67443, $user, $pass,
	[PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]'); 
?>
